package com.example.hermes.AboutUs;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.hermes.Home.HomeViewModel;
import com.example.hermes.MainActivity;
import com.example.hermes.R;

public class AboutUsFragment extends Fragment {

}
