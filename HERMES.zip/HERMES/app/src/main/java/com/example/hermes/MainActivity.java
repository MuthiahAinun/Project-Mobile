package com.example.hermes;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.content.Intent;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.navigation.ui.NavigationUI;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    TextView textView, TVEmail;
    SessionManager sessionManager;

    ImageView IVAbout, IVLogout, IVReceipe, IVNews, IVDiagnosis;
    private AppBarConfiguration mAppBarConfiguration;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        //TVEmail = findViewById(R.id.TVEmail);

        IVAbout = findViewById(R.id.IVAbout);
        IVLogout = findViewById(R.id.IVLogout);
        IVReceipe = findViewById(R.id.imageView5);
        IVNews = findViewById(R.id.imageView7);
        IVDiagnosis = findViewById(R.id.IVDiagnosis);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        sessionManager = new SessionManager(getApplicationContext());
        HashMap<String, String> user = sessionManager.getUserDetails();
        String name = user.get(SessionManager.kunci_email);
        textView.setText(Html.fromHtml("<b>" + name + "</b>"));
        //TVEmail.setText(Html.fromHtml("<b>" + name + "</b>"));

        //Megaktifkan Drawer
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.navigation_draw_open,R.string.navigation_draw_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        //Mengaktifkan Navigation
        NavigationView navigationView=findViewById(R.id.nav_view);
        //navigationView.setNavigationItemSelectedListener(this);
        View header = LayoutInflater.from(this).inflate(R.layout.nav_header_main, null);
        navigationView.addHeaderView(header);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                int id = item.getItemId();

                //Jika memilih navigasi home maka user diarahkan ke home
                if (id == R.id.home) {

                    Intent NextPage;
                    NextPage = new Intent(MainActivity.this, MainActivity.class);
                    startActivity(NextPage);

                    //Jika memilih navigasi activity maka user diarahkan ke activity
                }
                else if (id == R.id.user) {

                    Intent NextPage;
                    NextPage = new Intent(MainActivity.this, MyProfile.class);
                    startActivity(NextPage);
                }
                else if (id == R.id.location) {

                    Intent NextPage;
                    NextPage = new Intent(MainActivity.this, About.class);
                    startActivity(NextPage);
                }
                else if (id == R.id.favorite) {

                    Intent NextPage;
                    NextPage = new Intent(MainActivity.this, About.class);
                    startActivity(NextPage);
                }
                else if (id == R.id.about) {

                    Intent NextPage;
                    NextPage = new Intent(MainActivity.this, About.class);
                    startActivity(NextPage);
                }

                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
                //return true;
                return false;
            }
        });



        IVReceipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(getApplicationContext(), List_View.class));
               finish();
            }
        });

        IVNews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), News_LV.class));
                finish();
            }
        });

        IVAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), About.class));
                finish();
            }
        });

        IVDiagnosis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Diagnosa.class));
                finish();
            }
        });

        IVLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessionManager.logout();
            }
        });

        }
    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();

    }

}