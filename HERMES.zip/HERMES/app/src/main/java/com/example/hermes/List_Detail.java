package com.example.hermes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class List_Detail extends AppCompatActivity {

    ImageView TVResultGambar;
    TextView TVResult1, TVResult2, TVResult3;
    Toolbar toolbar;


    String nama,khasiat,keterangan;
    int gambar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_detail);

        TVResultGambar = findViewById(R.id.idTVResultGambar);
        TVResult1 = findViewById(R.id.idTVResult1);
        TVResult2 = findViewById(R.id.idTVResult2);
        TVResult3 = findViewById(R.id.idTVResult3);
        toolbar = findViewById(R.id.idToolbar1);

        toolbar.setNavigationIcon(R.drawable.ic_baseline_arrow_back_24);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                onBackPressed();
            }
        });


        nama = getIntent().getStringExtra("Nama");
        khasiat = getIntent().getStringExtra("Khasiat");
        keterangan = getIntent().getStringExtra("Keterangan");
        gambar = getIntent().getIntExtra("Gambar",0);



        TVResult1.setText(nama);
        TVResult2.setText(khasiat);
        TVResult3.setText(keterangan);
        TVResultGambar.setImageResource(gambar);
    }
}