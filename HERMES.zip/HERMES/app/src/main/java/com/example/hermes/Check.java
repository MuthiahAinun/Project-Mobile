package com.example.hermes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Check extends AppCompatActivity {

    CheckBox cb1,cb2,cb3,cb4,cb5,cb6,cb7,cb8,cb9,cb10,cb11,cb12,cb13,cb14,cb15,cb16,
    cb17,cb18,cb19,cb20,cb21,cb22,cb23,cb24,cb25,cb26,cb27,cb28,cb29,cb30,cb31,cb32,cb33,cb34,cb35,cb36,cb37,cb38;

    Button btnCheck;
    TextView tvOutput;

    ImageView IVBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);

        IVBack = findViewById(R.id.ivBack);
        IVBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Diagnosa.class));
                finish();
            }
        });

        cb1 = (CheckBox)findViewById(R.id.cb1);
        cb2 = (CheckBox)findViewById(R.id.cb2);
        cb3 = (CheckBox)findViewById(R.id.cb3);
        cb4 = (CheckBox)findViewById(R.id.cb4);
        cb5 = (CheckBox)findViewById(R.id.cb5);
        cb6 = (CheckBox)findViewById(R.id.cb6);
        cb7 = (CheckBox)findViewById(R.id.cb7);
        cb8 = (CheckBox)findViewById(R.id.cb8);
        cb9 = (CheckBox)findViewById(R.id.cb9);
        cb10 = (CheckBox)findViewById(R.id.cb10);
        cb11 = (CheckBox)findViewById(R.id.cb11);
        cb12 = (CheckBox)findViewById(R.id.cb12);
        cb13 = (CheckBox)findViewById(R.id.cb13);
        cb14 = (CheckBox)findViewById(R.id.cb14);
        cb15 = (CheckBox)findViewById(R.id.cb15);
        cb16 = (CheckBox)findViewById(R.id.cb16);
        cb17 = (CheckBox)findViewById(R.id.cb17);
        cb18 = (CheckBox)findViewById(R.id.cb18);
        cb19 = (CheckBox)findViewById(R.id.cb19);
        cb20 = (CheckBox)findViewById(R.id.cb20);
        cb21 = (CheckBox)findViewById(R.id.cb21);
        cb22 = (CheckBox)findViewById(R.id.cb22);
        cb23 = (CheckBox)findViewById(R.id.cb23);
        cb24 = (CheckBox)findViewById(R.id.cb24);
        cb25 = (CheckBox)findViewById(R.id.cb25);
        cb26 = (CheckBox)findViewById(R.id.cb26);
        cb27 = (CheckBox)findViewById(R.id.cb27);
        cb28 = (CheckBox)findViewById(R.id.cb28);
        cb29 = (CheckBox)findViewById(R.id.cb29);
        cb30 = (CheckBox)findViewById(R.id.cb30);
        cb31 = (CheckBox)findViewById(R.id.cb31);
        cb32 = (CheckBox)findViewById(R.id.cb32);
        cb33 = (CheckBox)findViewById(R.id.cb33);
        cb34 = (CheckBox)findViewById(R.id.cb34);
        cb35 = (CheckBox)findViewById(R.id.cb35);
        cb36 = (CheckBox)findViewById(R.id.cb36);
        cb37 = (CheckBox)findViewById(R.id.cb37);
        cb38 = (CheckBox)findViewById(R.id.cb38);

        btnCheck = (Button) findViewById(R.id.btnCheck);
        tvOutput = (TextView) findViewById(R.id.tvOutput);

        tvOutput.setText("");
        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Result = "Anda Menderita penyakit :";

                //GERD
                if(cb2.isChecked() && cb4.isChecked() && cb3.isChecked() && cb5.isChecked()){
                    Result += "\nGERD";
                }

                //Tukak Lambung
                if(cb6.isChecked() && cb3.isChecked() && cb7.isChecked() && cb8.isChecked() && cb9.isChecked()){
                    Result += "\nTukak Lambung";
                }

                //IBS atau Iritasi Usus Besar
                if(cb6.isChecked() && cb10.isChecked() && cb11.isChecked() && cb12.isChecked()){
                    Result += "\nIritasi Usus Besar";
                }

                //Diare
                if(cb3.isChecked() && cb13.isChecked() && cb14.isChecked() && cb15.isChecked() && cb16.isChecked() && cb1.isChecked()){
                    Result += "\nDiare";
                }

                //Asam Urat
                if(cb17.isChecked() && cb18.isChecked() && cb19.isChecked()){
                    Result += "\nAsam Urat";
                }

                //AIDS atau HIV
                if(cb20.isChecked() && cb1.isChecked() && cb10.isChecked() && cb21.isChecked() && cb22.isChecked() && cb8.isChecked() && cb23.isChecked()){
                    Result += "\nHIV/AIDS";
                }

                //Alergi Mata
                if(cb24.isChecked() && cb25.isChecked()){
                    Result += "\nAlergi Mata";
                }

                //Alergi Kulit
                if(cb26.isChecked() && cb23.isChecked()){
                    Result += "\nAlergi Kulit";
                }

                //Asma
                if(cb27.isChecked() && cb28.isChecked() && cb29.isChecked() && cb30.isChecked() && cb5.isChecked() && cb31.isChecked()){
                    Result += "\nAsma";
                }

                //Herpes
                if(cb22.isChecked() && cb26.isChecked() && cb1.isChecked() && cb32.isChecked() && cb19.isChecked() && cb33.isChecked()){
                    Result += "\nHerpes";
                }

                //Batu Ginjal
                if(cb34.isChecked() && cb15.isChecked() && cb35.isChecked() && cb36.isChecked() && cb37.isChecked() && cb38.isChecked() && cb3.isChecked() && cb22.isChecked() && cb1.isChecked()){
                    Result += "\nBatu Ginjal";
                }

                tvOutput.setText(""+Result);

            }
        });

    }
        public void onCheckboxClicked(View view) {
            boolean checked = ((CheckBox) view).isChecked();
            String str="";

            //Menampilkan pesan toast ke layar
            switch (view.getId()) {
                case  R.id.cb1:
                    str = checked?"Ada Gejala Demam": "Tidak Ada Gejala Demam";
                    break;
                case  R.id.cb2:
                    str = checked?"Ada Gejala Sensasi Terbakar Di Dada": "Tidak Ada Gejala Sensasi Terbakar Di Dada";
                    break;
                case  R.id.cb3:
                    str = checked?"Ada Gejala Mual Dan Muntah": "Tidak Ada Gejala Mual Dan Muntah";
                    break;
                case  R.id.cb4:
                    str = checked?"Ada Gejala Sulit Menelan": "Tidak Ada Gejala Sulit Menelan";
                    break;
                case  R.id.cb5:
                    str = checked?"Ada Gejala Batuk": "Tidak Ada Gejala Batuk";
                    break;
                case  R.id.cb6:
                    str = checked?"Ada Gejala Kembung": "Tidak Ada Gejala Kembung";
                    break;
                case  R.id.cb7:
                    str = checked?"Ada Gejala Feses Berwarna Gelap": "Tidak Ada Gejala Feses Berwarna Gelap";
                    break;
                case  R.id.cb8:
                    str = checked?"Ada Gejala Berat Badan Turun": "Tidak Ada Gejala Berat Badan Turun";
                    break;
                case  R.id.cb9:
                    str = checked?"Ada Gejala Hilang Nafsu Makan": "Tidak Ada Gejala Hilang Nafsu Makan";
                    break;
                case  R.id.cb10:
                    str = checked?"Ada Gejala Diare": "Tidak Ada Gejala Diare";
                    break;
                case  R.id.cb11:
                    str = checked?"Ada Gejala Sembelit": "Tidak Ada Gejala Sembelit";
                    break;
                case  R.id.cb12:
                    str = checked?"Ada Gejala Muncul Lendir Pada Feses": "Tidak Ada Gejala Muncul Lendir Pada Feses";
                    break;
                case  R.id.cb13:
                    str = checked?"Ada Gejala Muncul Darah Pada Feses": "Tidak Ada Gejala Muncul Darah Pada Feses";
                    break;
                case  R.id.cb14:
                    str = checked?"Ada Gejala Lemas Dan Pusing": "Tidak Ada Gejala Lemas Dan Pusing";
                    break;
                case  R.id.cb15:
                    str = checked?"Ada Gejala Kram Pada Bagian Perut": "Tidak Ada Gejala Kram Pada Bagian Perut";
                    break;
                case  R.id.cb16:
                    str = checked?"Ada Gejala Dehidrasi": "Tidak Ada Gejala Dehidrasi";
                    break;
                case  R.id.cb17:
                    str = checked?"Ada Gejala Nyeri": "Tidak Ada Gejala Nyeri";
                    break;
                case  R.id.cb18:
                    str = checked?"Ada Gejala Pembengkakan Pada Sendi": "Tidak Ada Gejala Pembengkakan Pada Sendi";
                    break;
                case  R.id.cb19:
                    str = checked?"Ada Gejala Warna Kulit Merah dan Panas": "Tidak Ada Gejala Warna Kulit Merah dan Panas";
                    break;
                case  R.id.cb20:
                    str = checked?"Ada Gejala Keringat Berlebih": "Tidak Ada Gejala Keringat Berlebih";
                    break;
                case  R.id.cb21:
                    str = checked?"Ada Gejala Bintik Putih Pada Lidah Atau Mulut": "Tidak Ada Gejala Bintik Putih Pada Lidah Atau Mulut";
                    break;
                case  R.id.cb22:
                    str = checked?"Ada Gejala Kelelahan Jangka Panjang": "Tidak Ada Gejala Kelelahan Jangka Panjang";
                    break;
                case  R.id.cb23:
                    str = checked?"Ada Gejala Ruam Pada Kulit": "Tidak Ada Gejala Ruam Pada Kulit";
                    break;
                case  R.id.cb24:
                    str = checked?"Ada Gejala Mata Merah": "Tidak Ada Gejala Mata Merah";
                    break;
                case  R.id.cb25:
                    str = checked?"Ada Gejala Mata Gatal Dan Berair": "Tidak Ada Gejala Mata Gatal Dan Berair";
                    break;
                case  R.id.cb26:
                    str = checked?"Ada Gejala Kulit Terasa Gatal": "Tidak Ada Gejala Kulit Terasa Gatal";
                    break;
                case  R.id.cb27:
                    str = checked?"Ada Gejala Nafas Pendek": "Tidak Ada Gejala Nafas Pendek";
                    break;
                case  R.id.cb28:
                    str = checked?"Ada Gejala Dada Nyeri Atau Sakit": "Tidak Ada Gejala Dada Nyeri Atau Sakit";
                    break;
                case  R.id.cb29:
                    str = checked?"Ada Gejala Sulit Tidur Akibat Sesak Nafas": "Tidak Ada Gejala Sulit Tidur Akibat Sesak Nafas";
                    break;
                case  R.id.cb30:
                    str = checked?"Ada Gejala Nafas Bunyi Seperti Siulan": "Tidak Ada Gejala Nafas Bunyi Seperti Siulan";
                    break;
                case  R.id.cb31:
                    str = checked?"Ada Gejala Bersin-bersin": "Tidak Ada Gejala Bersin-bersin";
                    break;
                case  R.id.cb32:
                    str = checked?"Ada Gejala Sensitif Terhadap Sentuhan": "Tidak Ada Gejala Sensitif Terhadap Sentuhan";
                    break;
                case  R.id.cb33:
                    str = checked?"Ada Gejala Kulit Melepuh Dan Timbul Bintik Cair": "Tidak Ada Gejala Kulit Melepuh Dan Timbul Bintik Cair";
                    break;
                case  R.id.cb34:
                    str = checked?"Ada Gejala Nyeri Pada Punggung": "Tidak Ada Gejala Nyeri Pada Punggung";
                    break;
                case  R.id.cb35:
                    str = checked?"Ada Gejala Nyeri Pada Area Selangkangan": "Tidak Ada Gejala Nyeri Pada Area Selangkangan";
                    break;
                case  R.id.cb36:
                    str = checked?"Ada Gejala Nyeri Saat Buang Air Kecil": "Tidak Ada Gejala Nyeri Saat Buang Air Kecil";
                    break;
                case  R.id.cb37:
                    str = checked?"Ada Gejala Muncul Darah Pada Urine": "Tidak Ada Gejala Muncul Darah Pada Urine";
                    break;
                case  R.id.cb38:
                    str = checked?"Ada Gejala Warna Urine Cenderung Merah Atau Coklat": "Tidak Ada Gejala Warna Urine Cenderung Merah Atau Coklat";
                    break;
            }

            //Tampilkan Pesan
            Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
        }

}