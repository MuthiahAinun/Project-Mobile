package com.example.hermes.Favorite;

public class FavoriteFragment {
}
