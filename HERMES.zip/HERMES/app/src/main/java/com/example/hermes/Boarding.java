package com.example.hermes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;

import com.ramotion.paperonboarding.PaperOnboardingFragment;
import com.ramotion.paperonboarding.PaperOnboardingPage;

import java.util.ArrayList;

public class Boarding extends AppCompatActivity {
    SessionManager sessionManager;

    private FragmentManager fragmentManager;

    SharedPreferences mSharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boarding);
        SessionManager sessionManager = new SessionManager(getApplicationContext());

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                sessionManager.checkLogin();
                finish();
            }
        },5000);

        fragmentManager = getSupportFragmentManager();

        final PaperOnboardingFragment paperOnboardingFragment = PaperOnboardingFragment.newInstance(getDataForOnBoarding());

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.fragment_container,paperOnboardingFragment);
        fragmentTransaction.commit();

}

    private ArrayList<PaperOnboardingPage> getDataForOnBoarding() {

      PaperOnboardingPage scr1 = new PaperOnboardingPage("Herbs", "Have many health benefits",
              Color.parseColor("#CFFFCC"), R.drawable.herbal, R.drawable.well);
      PaperOnboardingPage scr2 = new PaperOnboardingPage("Safety", "Save f or the body because it comes from the nature",
              Color.parseColor("#22eaaa"), R.drawable.shield, R.drawable.security);
      PaperOnboardingPage scr3 = new PaperOnboardingPage("Free", "Can be found all around us",
              Color.parseColor("#FFFFFF00"), R.drawable.lowest, R.drawable.down);

      ArrayList<PaperOnboardingPage> elements = new ArrayList<>();
      elements.add(scr1);
      elements.add(scr2);
      elements.add(scr3);
      return elements;
    }
    }