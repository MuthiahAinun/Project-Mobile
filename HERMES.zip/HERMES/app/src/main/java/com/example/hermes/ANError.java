package com.example.hermes;

public interface ANError {
    String getErrorBody();
}
