package com.example.hermes.Location;

public class LocationFragment {
}
