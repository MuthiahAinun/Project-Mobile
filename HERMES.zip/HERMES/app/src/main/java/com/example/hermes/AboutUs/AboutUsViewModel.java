package com.example.hermes.AboutUs;

public class AboutUsViewModel {
}
