package com.example.admin_hermes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class List_View extends AppCompatActivity {

    ImageView IV2, IV3;

    SwipeRefreshLayout srl_main;
    ArrayList<String> array_name, array_manfaat, array_pengolahan, array_photo;
    ProgressDialog progressDialog;
    ListView listProses;

    private Context mContext;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        //proses menghubungkan ke layout
        listProses = findViewById(R.id.LV);
        srl_main = findViewById(R.id.swipe_container);
        progressDialog = new ProgressDialog(this);

        IV2 = findViewById(R.id.imageView2);
        IV3 = findViewById(R.id.imageView3);

        srl_main.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                scrollRefresh();
                srl_main.setRefreshing(false);
            }
        });
        // Scheme colors for animation
        srl_main.setColorSchemeColors(
                getResources().getColor(android.R.color.holo_blue_bright),
                getResources().getColor(android.R.color.holo_green_light),
                getResources().getColor(android.R.color.holo_orange_light),
                getResources().getColor(android.R.color.holo_red_light)

        );
        scrollRefresh();

        IV2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                finish();
            }
        });
        IV3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Add_Receipe.class));
                finish();
            }
        });

    }

    public void scrollRefresh() {
        progressDialog.setMessage("Mengambil Data ...");
        progressDialog.setCancelable(false);
        progressDialog.show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                getData();
            }
        },2000);
    }
    void initializeArray(){
        array_name          = new ArrayList<String>();
        array_manfaat       = new ArrayList<String>();
        array_pengolahan    = new ArrayList<String>();
        array_photo         = new ArrayList<String>();

        array_name.clear();
        array_manfaat.clear();
        array_pengolahan.clear();
        array_photo.clear();
    }
    public void getData(){
        initializeArray();
        AndroidNetworking.get("https://tekajeapunya.com/kelompok_2/getData.php")
                .setTag("Get Data")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        progressDialog.dismiss();

                        try {
                            Boolean status = response.getBoolean("status");
                            if(status){
                                JSONArray ja = response.getJSONArray("result");
                                Log.d("respon", ""+ja);
                                for (int i = 0 ; i < ja.length(); i++){
                                    JSONObject jo = ja.getJSONObject(i);

                                    array_name.add(jo.getString("name"));
                                    array_manfaat.add(jo.getString("manfaat"));
                                    array_pengolahan.add(jo.getString("pengolahan"));
                                    array_photo.add(jo.getString("photo"));
                                }
                                // Data Adapter
                                final CLV_DataUser adapter = new  CLV_DataUser(List_View.this,array_name,array_manfaat,array_pengolahan,array_photo);

                                listProses.setAdapter(adapter);
                                listProses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                        Log.d("TestKlik", ""+array_name.get(position));
                                        Toast.makeText(List_View.this, array_name.get(position), Toast.LENGTH_SHORT).show();

                                        Intent i = new Intent(List_View.this,Result.class);
                                        i.putExtra("name", array_name.get(position));
                                        i.putExtra("manfaat", array_manfaat.get(position));
                                        i.putExtra("pengolahan", array_pengolahan.get(position));
                                        i.putExtra("photo", array_photo.get(position));
                                        startActivity(i);
                                    }
                                });
                            }else{
                                Toast.makeText(List_View.this, "Gagal Mengambil Data", Toast.LENGTH_SHORT).show();
                            }
                        }
                        catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                    @Override
                    public void onError(ANError anError) {
                    }
                });
    }

}