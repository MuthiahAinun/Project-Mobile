package com.example.admin_hermes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class Splash extends AppCompatActivity {
    SessionManager sessionManager;

    Animation slidedown_anim, slideup_anim;
    ImageView image;
    TextView logo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        SessionManager sessionManager = new SessionManager(getApplicationContext());

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                sessionManager.checkLogin();
                finish();
            }
        },5000);


        slideup_anim = AnimationUtils.loadAnimation(this,R.anim.slideup_anim);
        slidedown_anim = AnimationUtils.loadAnimation(this,R.anim.slidedown_anim);

        image = findViewById(R.id.logo);
        logo = findViewById(R.id.TV1);

        logo.setAnimation(slideup_anim);
        image.setAnimation(slidedown_anim);

    }
}