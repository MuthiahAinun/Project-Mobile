package com.example.admin_hermes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.navigation.ui.AppBarConfiguration;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    TextView textView, TVEmail;
    SessionManager sessionManager;

    ImageView IVAbout, IVLogout, IVReceipe, IVNews, IVDiagnosis;
    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        //TVEmail = findViewById(R.id.TVEmail);

        IVAbout = findViewById(R.id.IVAbout);
        IVLogout = findViewById(R.id.IVLogout);
        IVReceipe = findViewById(R.id.imageView5);
        IVNews = findViewById(R.id.imageView7);
        IVDiagnosis = findViewById(R.id.IVDiagnosis);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        sessionManager = new SessionManager(getApplicationContext());
        HashMap<String, String> user = sessionManager.getUserDetails();
        String name = user.get(SessionManager.kunci_email);
        textView.setText(Html.fromHtml("<b>" + name + "</b>"));


        IVReceipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), List_View.class));
                finish();
            }
        });

        IVNews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), News_LV.class));
                finish();
            }
        });

        IVAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), About.class));
                finish();
            }
        });

        IVDiagnosis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), MyProfile.class));
                finish();
            }
        });

        IVLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessionManager.logout();
            }
        });

    }
}