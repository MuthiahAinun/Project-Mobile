package com.example.admin_hermes;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONObject;

public class Login extends AppCompatActivity {


    EditText ETEmail,ETPass;
    String email,password;
    ProgressDialog progressDialog;

    Button Button3;
    //preferences
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //preferences
        sessionManager = new SessionManager(getApplicationContext());

        ETEmail     = findViewById(R.id.ETEmail);
        ETPass      = findViewById(R.id.ETPass);
        Button3 = findViewById(R.id.button3);
        progressDialog = new ProgressDialog(this);

        Button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                progressDialog.setMessage("Loading ...");
                progressDialog.setCancelable(false);
                progressDialog.show();

                email = ETEmail.getText().toString();
                password = ETPass.getText().toString();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() { validasiData(); }

                },1000);
            }
        });
    }
    void validasiData(){
        if(email.equals("") || password.equals("")){
            progressDialog.dismiss();
            Toast.makeText(Login.this,"Periksa kembali data Anda !", Toast.LENGTH_SHORT).show();
        }else  {
            kirimData();
        }
    }
    void kirimData(){



        AndroidNetworking.post("http://tekajeapunya.com/kelompok_2/verifyAdmin.php")
                .addBodyParameter("email",""+email)
                .addBodyParameter("password",""+password)
                .setPriority(Priority.MEDIUM)
                .setTag("Tambah Data")
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        progressDialog.dismiss();
                        Log.d("cekTambah",""+response);
                        try {
                            Boolean status = response.getBoolean("status");
                            String pesan   = response.getString("result");
                            Toast.makeText(Login.this, ""+pesan, Toast.LENGTH_SHORT).show();

                            Log.d("status",""+status);
                            if(status){
                                //preferences
                                sessionManager.createSession(ETEmail.getText().toString());

                                new AlertDialog.Builder(Login.this)
                                        .setMessage("Welcome Admin Hermes !")
                                        .setCancelable(false)
                                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                Intent i = new Intent(Login.this, MainActivity.class);
                                                startActivity(i);
                                            }
                                        })
                                        .show();
                            }
                            else{
                                new AlertDialog.Builder(Login.this)
                                        .setMessage("Periksa Kembali Email dan Password !")
                                        .setPositiveButton("Kembali", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                Intent i = new Intent(Login.this, Login.class);
                                                startActivity(i);
                                            }
                                        })
                                        .setCancelable(false)
                                        .show();
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(com.androidnetworking.error.ANError anError) {
                        Log.d("ErrorTambahData",""+anError.getErrorBody());
                    }

                });
    }
}