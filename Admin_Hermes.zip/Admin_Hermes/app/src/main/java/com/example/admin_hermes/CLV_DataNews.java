package com.example.admin_hermes;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CLV_DataNews extends ArrayAdapter<String> {

    private  final Activity context;
    private ArrayList<String> vName;
    private ArrayList<String> vPengertian;
    private ArrayList<String> vGejala;
    private ArrayList<String> vObat;
    private ArrayList<String> vPhoto;

    public  CLV_DataNews(Activity context, ArrayList<String> Name, ArrayList<String> Pengertian, ArrayList<String> Gejala, ArrayList<String> Obat, ArrayList<String> Photo){
        super(context, R.layout.activity_news_li, Name);
        this.context        = context;
        this.vName          = Name;
        this.vPengertian    = Pengertian;
        this.vGejala        = Gejala;
        this.vObat          = Obat;
        this.vPhoto         = Photo;

    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View rowView = inflater.inflate(R.layout.activity_news_li, null, true);
        TextView name       = rowView.findViewById(R.id.idTXTName);
        ImageView photo     = rowView.findViewById(R.id.idIVGambar);

        name.setText(vName.get(position));
        if (vPhoto.get(position).equals("")){
            Picasso.get().load("http://tekajeapunya.com/kelompok_2/image/noimage.png").into(photo);
        }else{
            Picasso.get().load("http://tekajeapunya.com/kelompok_2/image/"+vPhoto.get(position)).into(photo);
        }
        return rowView;
    }
}

