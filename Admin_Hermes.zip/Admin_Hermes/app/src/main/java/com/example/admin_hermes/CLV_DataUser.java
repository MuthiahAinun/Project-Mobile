package com.example.admin_hermes;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class CLV_DataUser extends ArrayAdapter<String> {

    private  final Activity context;
    private ArrayList<String> vName;
    private ArrayList<String> vManfaat;
    private ArrayList<String> vPengolahan;
    private ArrayList<String> vPhoto;

    public  CLV_DataUser(Activity context, ArrayList<String> Name, ArrayList<String> Manfaat, ArrayList<String> Pengolahan, ArrayList<String> Photo){
        super(context, R.layout.activity_list_item, Name);
        this.context        = context;
        this.vName          = Name;
        this.vManfaat       = Manfaat;
        this.vPengolahan    = Pengolahan;
        this.vPhoto         = Photo;

    }
    @SuppressLint("MissingInflatedId")
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View rowView = inflater.inflate(R.layout.activity_list_item, null, true);

        TextView name       = rowView.findViewById(R.id.idTXTName);
        ImageView photo     = rowView.findViewById(R.id.idIVGambar);

        name.setText(vName.get(position));
        if (vPhoto.get(position).equals("")){
            Picasso.get().load("http://tekajeapunya.com/kelompok_2/image/noimage.png").into(photo);
        }else{
            Picasso.get().load("http://tekajeapunya.com/kelompok_2/image/"+vPhoto.get(position)).into(photo);
        }
        return rowView;
    }
}

